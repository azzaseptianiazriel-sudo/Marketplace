
<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';

require_seller();

$uid = (int) current_user()['id'];

// Menghitung jumlah produk
$stmt = $conn->prepare(
    "SELECT COUNT(*) AS total FROM products WHERE seller_id=?"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$total_produk = $stmt->get_result()->fetch_assoc()['total'];

// Menghitung jumlah stok
$stmt = $conn->prepare(
    "SELECT COALESCE(SUM(stock), 0) AS total FROM products WHERE seller_id=?"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$total_stok = $stmt->get_result()->fetch_assoc()['total'];

// Mengambil produk terbaru
$stmt = $conn->prepare(
    "SELECT id, name, price, stock
     FROM products
     WHERE seller_id=?
     ORDER BY created_at DESC
     LIMIT 5"
);
$stmt->bind_param('i', $uid);
$stmt->execute();
$produk = $stmt->get_result();

$page_title = 'Dashboard Seller';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid">

    <div class="mb-4">
        <h2>Dashboard Seller</h2>
        <p class="text-muted">
            Selamat datang di halaman pengelolaan toko MarketKita.
        </p>
    </div>

    <!-- Ringkasan -->
    <div class="row g-3 mb-4">

        <div class="col-md-4">
            <div class="card shadow-sm p-4 h-100">
                <h6 class="text-muted">Total Produk</h6>
                <h2 class="fw-bold">
                    <?= (int)$total_produk ?>
                </h2>
                <a href="index.php">Kelola Produk →</a>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm p-4 h-100">
                <h6 class="text-muted">Total Stok</h6>
                <h2 class="fw-bold">
                    <?= (int)$total_stok ?>
                </h2>
                <span class="text-muted">Unit produk tersedia</span>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm p-4 h-100">
                <h6 class="text-muted">Pengelolaan Toko</h6>
                <h5 class="fw-bold">MarketKita Seller</h5>
                <a href="product_form.php">+ Tambah Produk</a>
            </div>
        </div>

    </div>

    <!-- Produk Terbaru -->
    <div class="card shadow-sm p-3">

        <div class="d-flex justify-content-between
                    align-items-center mb-3">

            <h5 class="mb-0">Produk Terbaru</h5>

            <a href="index.php"
               class="btn btn-primary btn-sm">
                Lihat Semua
            </a>

        </div>

        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Status Stok</th>
                    </tr>
                </thead>

                <tbody>

                <?php if ($produk->num_rows > 0): ?>

                    <?php while ($p = $produk->fetch_assoc()): ?>

                    <tr>
                        <td><?= e($p['name']) ?></td>

                        <td>
                            <?= rupiah($p['price']) ?>
                        </td>

                        <td>
                            <?= (int)$p['stock'] ?>
                        </td>

                        <td>
                            <?php if ($p['stock'] > 0): ?>
                                <span class="badge bg-success">
                                    Tersedia
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger">
                                    Habis
                                </span>
                            <?php endif; ?>
                        </td>
                    </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="4" class="text-center">
                            Belum ada produk.
                        </td>
                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
