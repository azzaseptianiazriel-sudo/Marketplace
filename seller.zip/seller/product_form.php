<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_seller(); $uid=(int)current_user()['id']; $id=(int)($_GET['id']??0); $p=['name'=>'','description'=>'','price'=>'','stock'=>'','category_id'=>'','image_url'=>'']; $error='';
if($id){$s=$conn->prepare("SELECT * FROM products WHERE id=? AND seller_id=?");$s->bind_param('ii',$id,$uid);$s->execute();$found=$s->get_result()->fetch_assoc();if(!$found)exit('Produk tidak ditemukan atau bukan milik Anda.');$p=$found;}
if($_SERVER['REQUEST_METHOD']==='POST'){
 verify_csrf(); $name=trim($_POST['name']??'');$desc=trim($_POST['description']??'');$price=(float)($_POST['price']??0);$stock=(int)($_POST['stock']??0);$cat=(int)($_POST['category_id']??0);$img=trim($_POST['image_url']??'');
 if(!$name || $price<=0 || $stock<0) $error='Nama, harga, dan stok harus diisi dengan benar.';
 else {
  $catval=$cat?:null; $imgval=$img?:null;
  if($id){$s=$conn->prepare("UPDATE products SET category_id=?,name=?,description=?,price=?,stock=?,image_url=? WHERE id=? AND seller_id=?");$s->bind_param('issdisii',$catval,$name,$desc,$price,$stock,$imgval,$id,$uid);}
  else {$s=$conn->prepare("INSERT INTO products(seller_id,category_id,name,description,price,stock,image_url) VALUES(?,?,?,?,?,?,?)");$s->bind_param('iissdis',$uid,$catval,$name,$desc,$price,$stock,$imgval);}
  $s->execute();set_flash('Produk berhasil disimpan.');header('Location: index.php');exit;
 }
}
$cats=$conn->query("SELECT * FROM categories ORDER BY name");
$page_title=$id?'Edit Produk':'Tambah Produk';require_once __DIR__.'/../includes/header.php';
?>
<div class="row justify-content-center"><div class="col-lg-8"><div class="card p-4"><h2><?= $id?'Edit':'Tambah' ?> Produk</h2>
<?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
<div class="mb-3"><label class="form-label">Nama Produk</label><input class="form-control" name="name" required value="<?= e($_POST['name']??$p['name']) ?>"></div>
<div class="mb-3"><label class="form-label">Kategori</label><select class="form-select" name="category_id"><option value="0">Pilih kategori</option><?php while($c=$cats->fetch_assoc()): ?><option value="<?= (int)$c['id'] ?>" <?= (int)($p['category_id']??0)===(int)$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endwhile; ?></select></div>
<div class="mb-3"><label class="form-label">Deskripsi</label><textarea class="form-control" name="description" rows="4"><?= e($_POST['description']??$p['description']) ?></textarea></div>
<div class="row"><div class="col-md-6 mb-3"><label class="form-label">Harga (Rp)</label><input class="form-control" type="number" min="1" name="price" required value="<?= e($_POST['price']??$p['price']) ?>"></div><div class="col-md-6 mb-3"><label class="form-label">Stok</label><input class="form-control" type="number" min="0" name="stock" required value="<?= e($_POST['stock']??$p['stock']) ?>"></div></div>
<div class="mb-3"><label class="form-label">URL Gambar (opsional)</label><input class="form-control" name="image_url" value="<?= e($_POST['image_url']??$p['image_url']) ?>" placeholder="https://..."></div>
<button class="btn btn-primary">Simpan</button> <a class="btn btn-outline-secondary" href="index.php">Batal</a>
</form></div></div></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
