<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/functions.php';
require_seller(); verify_csrf();
$id=(int)($_POST['id']??0);$uid=(int)current_user()['id'];
try {$s=$conn->prepare("DELETE FROM products WHERE id=? AND seller_id=?");$s->bind_param('ii',$id,$uid);$s->execute();set_flash('Produk berhasil dihapus.');}
catch(mysqli_sql_exception $e){set_flash('Produk tidak dapat dihapus karena sudah tercatat dalam pesanan.','warning');}
header('Location: index.php');exit;
