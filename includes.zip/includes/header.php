<?php
require_once __DIR__ . '/functions.php';
$page_title = $page_title ?? 'MarketKita';
$flash = get_flash();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> | MarketKita</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="<?= e(url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark mk-navbar sticky-top">
 <div class="container">
  <a class="navbar-brand fw-bold" href="<?= e(url('index.php')) ?>">Market<span>Kita</span></a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"><span class="navbar-toggler-icon"></span></button>
  <div class="collapse navbar-collapse" id="mainNav">
   <ul class="navbar-nav me-auto">
    <li class="nav-item"><a class="nav-link" href="<?= e(url('index.php')) ?>">Beranda</a></li>
    <li class="nav-item"><a class="nav-link" href="<?= e(url('index.php#produk')) ?>">Produk</a></li>
    <?php if (is_logged_in() && current_user()['role'] === 'admin'): ?>
      <li class="nav-item"><a class="nav-link" href="<?= e(url('admin/dashboard.php')) ?>">Dashboard Admin</a></li>
    <?php endif; ?>
    <?php if (is_logged_in() && current_user()['role'] === 'pembeli'): ?>
      <li class="nav-item"><a class="nav-link" href="<?= e(url('orders.php')) ?>">Pesanan Saya</a></li>
    <?php endif; ?>
   </ul>
   <div class="d-flex align-items-center gap-2">
    <a class="btn btn-outline-light btn-sm position-relative" href="<?= e(url('cart.php')) ?>">Keranjang <span class="badge bg-warning text-dark"><?= (int)cart_count() ?></span></a>
    <?php if (is_logged_in()): ?>
      <span class="text-white small d-none d-md-inline">Halo, <?= e(current_user()['name']) ?></span>
      <a class="btn btn-light btn-sm" href="<?= e(url('logout.php')) ?>">Keluar</a>
    <?php else: ?>
      <a class="btn btn-light btn-sm" href="<?= e(url('login.php')) ?>">Masuk</a>
      <a class="btn btn-warning btn-sm" href="<?= e(url('register.php')) ?>">Daftar</a>
    <?php endif; ?>
   </div>
  </div>
 </div>
</nav>
<main class="container py-4">
<?php if ($flash): ?><div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show"><?= e($flash['message']) ?><button class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
