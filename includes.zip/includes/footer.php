</main>
<footer class="mk-footer mt-5 py-4"><div class="container d-flex flex-column flex-md-row justify-content-between gap-2"><span class="fw-bold">MarketKita</span><span class="small">Marketplace produk kebutuhan sehari-hari · PHP Native & MySQLi</span></div></footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body></html>
