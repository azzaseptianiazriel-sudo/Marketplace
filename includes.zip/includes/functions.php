<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function url($path = '') {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function rupiah($value) {
    return 'Rp ' . number_format((float)$value, 0, ',', '.');
}
function redirect($path) {
    header('Location: ' . (preg_match('~^https?://~', $path) ? $path : url($path)));
    exit;
}
function current_user() {
    return $_SESSION['user'] ?? null;
}
function is_logged_in() {
    return current_user() !== null;
}
function require_login() {
    if (!is_logged_in()) {
        set_flash('Silakan login terlebih dahulu.', 'warning');
        redirect('login.php');
    }
}
function require_admin() {
    require_login();
    if ((current_user()['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Akses ditolak. Halaman ini khusus Admin.');
    }
}
function set_flash($message, $type = 'success') {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
function get_flash() {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}
function csrf_token() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf() {
    $token = $_POST['csrf'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) {
        http_response_code(419);
        exit('Permintaan tidak valid. Muat ulang halaman dan coba lagi.');
    }
}
function cart_count() {
    return array_sum($_SESSION['cart'] ?? []);
}
function product_image($image) {
    return $image ?: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=900&auto=format&fit=crop&q=80';
}
