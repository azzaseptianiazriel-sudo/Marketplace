<?php
require_once __DIR__.'/../includes/db.php';require_once __DIR__.'/../includes/functions.php';require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('admin/products.php');}verify_csrf();$id=(int)($_POST['id']??0);
try{$s=$conn->prepare("DELETE FROM products WHERE id=?");$s->bind_param('i',$id);$s->execute();set_flash($s->affected_rows?'Produk berhasil dihapus.':'Produk tidak ditemukan.',$s->affected_rows?'success':'warning');}
catch(mysqli_sql_exception $e){set_flash('Produk tidak dapat dihapus karena sudah digunakan dalam transaksi.','warning');}
redirect('admin/products.php');
