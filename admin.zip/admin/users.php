<?php
require_once __DIR__.'/_init.php';$rows=$conn->query("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC");$page_title='Pengguna';require_once __DIR__.'/../includes/header.php';
?>
<h1 class="section-title mb-4">Data Pengguna</h1><div class="surface-card p-3 table-responsive"><table class="table align-middle"><thead><tr><th>Nama</th><th>Email</th><th>Role</th><th>Terdaftar</th></tr></thead><tbody><?php while($u=$rows->fetch_assoc()): ?><tr><td><?= e($u['name']) ?></td><td><?= e($u['email']) ?></td><td><span class="badge <?= $u['role']==='admin'?'bg-dark':'bg-primary' ?>"><?= e($u['role']) ?></span></td><td><?= e($u['created_at']) ?></td></tr><?php endwhile; ?></tbody></table></div>
<?php require_once __DIR__.'/../includes/footer.php'; ?>
