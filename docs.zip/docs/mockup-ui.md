# Rancangan Mockup UI (konseptual)

1. **Daftar Produk**: navbar MarketKita, banner promosi, pencarian dan filter kategori, grid kartu produk dengan foto, nama, harga, stok, dan tombol detail.
2. **Detail Produk**: foto besar di kiri; kategori, nama, harga, deskripsi, stok, input jumlah, dan tombol tambah ke keranjang di kanan.
3. **Keranjang**: daftar produk dengan foto, harga, kuantitas, subtotal, tombol ubah/hapus, serta ringkasan total dan tombol checkout.
