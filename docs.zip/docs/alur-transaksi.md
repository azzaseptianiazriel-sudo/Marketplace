# Alur Transaksi MarketKita

```mermaid
flowchart TD
 A([Mulai]) --> B[Pembeli membuka katalog]
 B --> C[Pilih produk]
 C --> D[Lihat detail produk]
 D --> E{Stok tersedia?}
 E -- Tidak --> B
 E -- Ya --> F[Tambah ke keranjang]
 F --> G{Sudah login?}
 G -- Belum --> H[Login atau daftar]
 H --> I[Checkout]
 G -- Sudah --> I
 I --> J[Isi alamat dan nomor telepon]
 J --> K[Validasi stok dan total]
 K --> L{Data valid?}
 L -- Tidak --> F
 L -- Ya --> M[Simpan orders dan order_items]
 M --> N[Kurangi stok]
 N --> O[Tampilkan nomor pesanan]
 O --> P([Selesai])
```
