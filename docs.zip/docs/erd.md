# ERD MarketKita

```mermaid
erDiagram
    USERS ||--o{ ORDERS : membuat
    CATEGORIES ||--o{ PRODUCTS : mengelompokkan
    ORDERS ||--|{ ORDER_ITEMS : memiliki
    PRODUCTS o|--o{ ORDER_ITEMS : dipesan

    USERS {
      int id PK
      varchar name
      varchar email UK
      varchar password
      enum role
    }
    CATEGORIES {
      int id PK
      varchar name UK
    }
    PRODUCTS {
      int id PK
      int category_id FK
      varchar name
      text description
      decimal price
      int stock
      varchar image_url
    }
    ORDERS {
      int id PK
      int user_id FK
      decimal total_amount
      enum status
      text shipping_address
      varchar phone
    }
    ORDER_ITEMS {
      int id PK
      int order_id FK
      int product_id FK
      varchar product_name
      decimal price
      int quantity
      decimal subtotal
    }
```
