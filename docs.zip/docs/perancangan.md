# Dokumen Perancangan MarketKita

## 1. Tujuan
MarketKita adalah marketplace tradisional sederhana. Sistem memiliki dua role: Admin dan Pembeli. Admin mengelola katalog dan pesanan, sedangkan Pembeli mencari produk, memasukkan produk ke keranjang, dan membuat pesanan.

## 2. Entitas dan atribut

1. **users**: `id` (PK), `name`, `email` (unik), `password`, `role`, `created_at`.
2. **categories**: `id` (PK), `name`, `description`.
3. **products**: `id` (PK), `category_id` (FK), `name`, `description`, `price`, `stock`, `image`, `is_active`, `created_at`.
4. **orders**: `id` (PK), `order_code` (unik), `buyer_id` (FK), `recipient_name`, `phone`, `address`, `notes`, `payment_method`, `total`, `status`, `created_at`.
5. **order_items**: `id` (PK), `order_id` (FK), `product_id` (FK), `product_name`, `price`, `quantity`, `subtotal`.

## 3. Relasi antar tabel
- `users` 1 : N `orders`: satu Pembeli dapat membuat banyak pesanan.
- `categories` 1 : N `products`: satu kategori memiliki banyak produk.
- `orders` 1 : N `order_items`: satu pesanan terdiri dari satu atau banyak item.
- `products` 1 : N `order_items`: satu produk dapat tercatat pada banyak detail pesanan.

## 4. Alur transaksi
1. Pembeli membuka katalog produk.
2. Pembeli memilih produk untuk melihat detail.
3. Pembeli menentukan jumlah dan menambahkan produk ke keranjang.
4. Pembeli memperbarui jumlah atau menghapus item pada keranjang.
5. Pembeli login atau mendaftar.
6. Pembeli mengisi nama penerima, nomor telepon, alamat, dan metode pembayaran.
7. Sistem memeriksa ketersediaan stok.
8. Sistem menyimpan data ke tabel `orders` dan `order_items` dalam satu transaksi database.
9. Sistem mengurangi stok produk dan menampilkan nomor pesanan.
10. Admin melihat pesanan dan memperbarui statusnya.

## 5. Rancangan antarmuka
- **Daftar produk**: navbar MarketKita, banner, pencarian, filter kategori, kartu produk berisi gambar, nama, harga, stok, tombol detail dan keranjang.
- **Detail produk**: gambar besar, kategori, nama, harga, deskripsi, stok, input jumlah, tombol tambah ke keranjang.
- **Keranjang**: daftar gambar/nama produk, harga satuan, input jumlah, subtotal, tombol hapus, total belanja, tombol checkout.
- **Admin**: dashboard statistik, navigasi manajemen produk, kategori (data kategori disiapkan pada database), dan pesanan. Admin dapat melakukan CRUD produk dan memperbarui status pesanan.

## 6. Teknologi
PHP Native, MySQLi, MySQL/MariaDB, Bootstrap 5, HTML, CSS, dan session PHP.

## 7. Catatan implementasi
Gambar contoh produk tersedia lokal pada `assets/img/` dalam format SVG. Checkout menggunakan transaksi MySQL (`begin_transaction`, `commit`, `rollback`) dan memeriksa stok sebelum menyimpan pesanan.
